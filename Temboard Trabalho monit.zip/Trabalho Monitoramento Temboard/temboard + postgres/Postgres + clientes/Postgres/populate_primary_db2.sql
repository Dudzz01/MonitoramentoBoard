INSERT INTO Categoria_Produto (Nome, Descricao) VALUES 
('Eletrônicos', 'Dispositivos eletrônicos e gadgets'),
('Roupas', 'Vestuário e acessórios de moda'),
('Alimentos', 'Produtos alimentícios e bebidas');

INSERT INTO Produto (Nome, Descricao, Preco, Estoque, Data_de_Lancamento, ID_Categoria) VALUES 
('Smartphone X', 'Smartphone com tela de 6.1 polegadas', 799.99, 150, '2023-01-15', 1),
('Camisa Polo', 'Camisa polo de algodão', 29.99, 200, '2022-11-20', 2),
('Café Orgânico', 'Café orgânico de alta qualidade', 9.99, 500, '2023-02-01', 3);

INSERT INTO Cliente (Nome, Email, Telefone, Endereco, Data_de_Nascimento) VALUES 
('João Silva', 'joao.silva@example.com', '111-222-3333', 'Rua A, 123, São Paulo, SP', '1985-05-20'),
('Maria Souza', 'maria.souza@example.com', '222-333-4444', 'Av. B, 456, Rio de Janeiro, RJ', '1990-08-15'),
('Carlos Lima', 'carlos.lima@example.com', '333-444-5555', 'Rua C, 789, Belo Horizonte, MG', '1975-12-10');

INSERT INTO Campanha_Marketing (Nome, Descricao, Data_de_Inicio, Data_de_Termino, Orcamento, ID_Canal) VALUES 
('Promoção de Verão', 'Descontos especiais para o verão', '2023-06-01', '2023-08-31', 5000.00, 1),
('Black Friday', 'Ofertas imperdíveis na Black Friday', '2023-11-01', '2023-11-30', 10000.00, 2);

INSERT INTO Vendas (ID_Cliente, ID_Produto, Data_de_Venda, Quantidade, Valor_Total) VALUES 
(1, 1, '2023-01-20', 1, 799.99),
(2, 2, '2022-12-01', 3, 89.97),
(3, 3, '2023-02-05', 5, 49.95);

INSERT INTO Feedback_Cliente (ID_Cliente, ID_Produto, Data, Comentario, Avaliacao) VALUES 
(1, 1, '2023-01-25', 'Excelente smartphone, muito satisfeito!', 5),
(2, 2, '2022-12-05', 'Camisa de boa qualidade, mas poderia ser mais barata.', 4),
(3, 3, '2023-02-10', 'Café com ótimo sabor, recomendo.', 5);

INSERT INTO Canal_Marketing (Nome, Descricao, Tipo) VALUES 
('E-mail Marketing', 'Promoções e novidades enviadas por e-mail', 'E-mail'),
('Redes Sociais', 'Campanhas e anúncios nas redes sociais', 'Social Media');

INSERT INTO Segmento_Mercado (Nome, Descricao) VALUES 
('Tecnologia', 'Consumidores interessados em tecnologia e inovação'),
('Moda', 'Consumidores interessados em roupas e acessórios de moda'),
('Alimentação', 'Consumidores interessados em produtos alimentícios');

INSERT INTO Parceiro_Marketing (Nome, Contato, Tipo_Parceria) VALUES 
('Agência XYZ', 'contato@xyz.com', 'Agência de Publicidade'),
('Influenciador Digital', 'influencer@example.com', 'Promoção em redes sociais');

INSERT INTO Analise_Dados (ID_Campanha, ID_Produto, Data, Metricas) VALUES 
(1, 1, '2023-06-15', 'Cliques: 500, Conversões: 50, ROI: 200%'),
(2, 2, '2023-11-15', 'Cliques: 1000, Conversões: 150, ROI: 300%');

INSERT INTO Campanha_Produto (ID_Campanha, ID_Produto) VALUES 
(1, 1),
(2, 2),
(2, 3);

INSERT INTO Produto_Segmento (ID_Produto, ID_Segmento) VALUES 
(1, 1),
(2, 2),
(3, 3);

INSERT INTO Campanha_Parceiro (ID_Campanha, ID_Parceiro) VALUES 
(1, 1),
(2, 2);

