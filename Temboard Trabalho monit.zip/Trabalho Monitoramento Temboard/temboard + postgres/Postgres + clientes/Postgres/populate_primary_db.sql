CREATE TABLE Categoria_Produto (
    ID_Categoria serial PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Descricao TEXT
);

CREATE TABLE Produto (
    ID_Produto serial PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Descricao TEXT,
    Preco DECIMAL(10, 2) NOT NULL,
    Estoque INT NOT NULL,
    Data_de_Lancamento DATE,
    ID_Categoria INT,
    FOREIGN KEY (ID_Categoria) REFERENCES Categoria_Produto(ID_Categoria)
);

CREATE TABLE Cliente (
    ID_Cliente serial PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Telefone VARCHAR(20),
    Endereco TEXT,
    Data_de_Nascimento DATE
);

CREATE TABLE Canal_Marketing (
    ID_Canal serial PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Descricao TEXT,
    Tipo VARCHAR(50) NOT NULL
);

CREATE TABLE Campanha_Marketing (
    ID_Campanha serial PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Descricao TEXT,
    Data_de_Inicio DATE,
    Data_de_Termino DATE,
    Orcamento DECIMAL(10, 2),
    ID_Canal INT,
    FOREIGN KEY (ID_Canal) REFERENCES Canal_Marketing(ID_Canal)
);

CREATE TABLE Vendas (
    ID_Venda serial PRIMARY KEY,
    ID_Cliente INT,
    ID_Produto INT,
    Data_de_Venda DATE NOT NULL,
    Quantidade INT NOT NULL,
    Valor_Total DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (ID_Cliente) REFERENCES Cliente(ID_Cliente),
    FOREIGN KEY (ID_Produto) REFERENCES Produto(ID_Produto)
);

CREATE TABLE Feedback_Cliente (
    ID_Feedback serial PRIMARY KEY,
    ID_Cliente INT,
    ID_Produto INT,
    Data DATE NOT NULL,
    Comentario TEXT,
    Avaliacao INT CHECK (Avaliacao BETWEEN 1 AND 5),
    FOREIGN KEY (ID_Cliente) REFERENCES Cliente(ID_Cliente),
    FOREIGN KEY (ID_Produto) REFERENCES Produto(ID_Produto)
);



CREATE TABLE Segmento_Mercado (
    ID_Segmento serial PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Descricao TEXT
);

CREATE TABLE Parceiro_Marketing (
    ID_Parceiro serial PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Contato VARCHAR(100),
    Tipo_Parceria VARCHAR(100)
);

CREATE TABLE Analise_Dados (
    ID_Analise serial PRIMARY KEY,
    ID_Campanha INT,
    ID_Produto INT,
    Data DATE NOT NULL,
    Metricas TEXT,
    FOREIGN KEY (ID_Campanha) REFERENCES Campanha_Marketing(ID_Campanha),
    FOREIGN KEY (ID_Produto) REFERENCES Produto(ID_Produto)
);

CREATE TABLE Campanha_Produto (
    ID_Campanha INT,
    ID_Produto INT,
    PRIMARY KEY (ID_Campanha, ID_Produto),
    FOREIGN KEY (ID_Campanha) REFERENCES Campanha_Marketing(ID_Campanha),
    FOREIGN KEY (ID_Produto) REFERENCES Produto(ID_Produto)
);

CREATE TABLE Produto_Segmento (
    ID_Produto INT,
    ID_Segmento INT,
    PRIMARY KEY (ID_Produto, ID_Segmento),
    FOREIGN KEY (ID_Produto) REFERENCES Produto(ID_Produto),
    FOREIGN KEY (ID_Segmento) REFERENCES Segmento_Mercado(ID_Segmento)
);

CREATE TABLE Campanha_Parceiro (
    ID_Campanha INT,
    ID_Parceiro INT,
    PRIMARY KEY (ID_Campanha, ID_Parceiro),
    FOREIGN KEY (ID_Campanha) REFERENCES Campanha_Marketing(ID_Campanha),
    FOREIGN KEY (ID_Parceiro) REFERENCES Parceiro_Marketing(ID_Parceiro)
);
